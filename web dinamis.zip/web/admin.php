<h1> Anda Berhasil Login </h1>
<br>Jika Anda Ingin Logout <a href='logout.php'>Klik Di Sini</a> 

<?php include "proteksi.php"; ?>
<h1> Anda Berhasil Login </h1>
<br>Jika Anda Ingin Logout <a href='logout.php'>Klik Di Sini</a>x