<?php 

	session_start();
	if (isset($_SESSION['admin'])) {
		header("Location:utama.php");
	}

 ?>

<!DOCTYPE html>
<html style="background-image: url('background.jpg');
background-position-x: right;

}">
<head>
  <title>Login</title>

</head>
<body >
<h1 style="text-align: center; color: red;"> Silahkan login </h1>
    <form method="post" action="login.php" style=" margin-left: 541px;

height: 241px;
width: 277px;
background-color: #aeaeae;
border-left-width: 5px;
border-left-: solid;
border-tostylep-width: 5px;
border-top-style: solid;
border-right-width: 5px;
border-right-style: solid;
border-bottom-width: 5px;
border-bottom-style: solid;
border-left-style: solid;
border-left-style: solid;
border-top-width: 5px;
border-left-color: red;
border-bottom-color: red;
border-right-color: red;
border-top-color: red;
}">  
    	<label style="text-align: center;">User</label><br>
        <input type="text" name="user" placeholder="username" autofocus><br> 

        <label style="text-align: center;">Password</label><br>
        <input type="password" name="pass" placeholder="password" ><br>  
        <input type="submit" value="masuk"><br>
        Belum Punya Akun?<a href="register.php">Daftar</a>
    </form>
  
</body>
</html>