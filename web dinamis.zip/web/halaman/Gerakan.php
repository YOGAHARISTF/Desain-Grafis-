   <div>
 
 		<h1 class="centerh1">GERAKAN</h1>
		<div id="Gerakan">
			<img src="images/agi-uke.gif" id="foto"><br>
			<p>agi-uke</p><br>
		
		
			<img src="images/choku-zuki.gif" id="foto"><br>
			<p>choku-zuki</p><br>
		
		
			<img src="images/gedan-barai.gif" id="foto"><br>
			<p>gedan-barai</p><br>
		
		
			<img src="images/gyaku-zuki.gif" id="foto"><br>
			<p>gyaku-zuki</p><br>
		
		
			<img src="images/heisoku-dachi.gif" id="foto"><br>
			<p>heisoku-dachi</p><br>
		
		
			<img src="images/kakiwake-uke.gif" id="foto"><br>
			<p>kakiwake-uke</p><br>
		
		
			<img src="images/morote-zuki.gif" id="foto"><br>
			<p>morote-zuki</p><br>
		
		
			<img src="images/oi-zuki.gif" id="foto"><br>
			<p>oi-zuki</p><br>
		
		
			<img src="images/ushiro-geri.gif" id="foto"><br>
			<p>ushiro-geri</p><br>
		
		
			<img src="images/yoko-geri-kekome.gif" id="foto"><br>
			<p>yoko-geri-kekome</p><br>
		
	</div>
	