
	<h1>Kihon</h1>
		<p>Untuk teknik dasar satu ini dalam karate, secara harfiah memiliki makna fondasi dan itu artinya, setiap karatedo perlu menguasai Kihon secara sempurna sebelum pada akhirnya bisa mengenal dan mempelajari Kata serta Kumite.

Pada umumnya, pelatihan untuk teknik Kihon ini diawali dengan mempelajari gerakan menendang dan memukul yang kita kenal dengan tahap sabuk puti serta gerakan bantingan yang ada pada sebuk coklat. Ketika karatedo berada pada tahap dan/atau sabuk hitam, maka hal ini berarti karatedo telah berhasil menguasai seluruh Kihon.</p>
        <h2>Kata</h2>
        <p>ni adalah teknik dasar selanjutnya dalam karate di mana secara harfiah adalah bentuk atau pola dan di dalam karate, Kata bukan hanya pelatihan secara fisik biasa ataupun aerobik yang diduga banyak orang. Namun lebih dari itu, ada pelajaran tentang prinsip bertarung yang terkandung di dalam teknik dasar Kata ini.

Ada terkandung falsafah-falsafah hidup juga di dalam banyak gerakan Kata dan ada ritme gerakan serta penapasan yang tak sama antara satu dengan lainnya pada setiap Kata. Ada istilah Bunkai di dalam Kata di mana ini adalah sebuah aplikasi yang karatedo bisa gunakan dari gerakan dasar Kata itu sendiri.

Untuk tiap Kata, tiap aliran mempunyai gerak dan nama yang berbeda-beda. Ambil contoh, Kata Tekki yang ada pada aliran Shotokan yang lebih dikenal dengan istilah Naihanchi yang ada di aliran Shito Ryu dan inilah yang memengaruhi Bunkai pada setiap aliran juga menjadi tak sama antara satu dan yang lain.</p>
        <h3>Kumite</h3>
        <p>Pertemuan tangan adalah makna harfiah dari Kumite ini dan biasanya teknik ini dilakukan khususnya oleh para karatedo yang sudah berada pada tingkat lanjut, seperti sabuk biru atau lebih. Hanya saja, zaman sekarang ada dojo yang sudah menawarkan pengajaran/pelatihan Kumite pada praktisi sabuk kuning atau yang masih pada tingkat pemula.

Go hon kumite atau kumite yang diatur adalah yang pertama kali dipelajari oleh para karatedo sebelum melakukan kumite bebas atau jiyu kumite.

Untuk aliran kontak langsung atau yang juga dikenal dengan Kyokushin, karatedo perlu membiasakan melakukan teknik ini ketika berada pada tingkat sabuk biru strip. Para karatedo atau praktisi Kyokushin ini boleh melancarkan pukulan maupun tendangan ke arah lawan saat bertanding sekuat tenaga.
Untuk aliran Shotokan yang ada di Jepang, teknik kumite ini hanya bagi karatedo yang sudah berada pada tingkat sabuk hitam. Karatedo dalam hal ini diwajibkan mampu menjaga setiap pukulan agar kawan yang menjadi pasangan berlatih dan bertanding tak cedera.
Untuk aliran Wado-ryu yang menjadi aliran kombinasi dengan teknik yang kita ketahui terdiri dari campuran Jujutsu dan Karate ini, teknik Kumite terdiri dari 2 jenis. Yang pertama adalah persiapan Shiai di mana pelatihannya hanya teknik-teknik yang memang diperbolehkan untuk pertandingan. Kedua adalah Goshinjutsu Kumite di mana di sinilah praktik penggunaan seluruh teknik; itulah mengapa ini juga disebut dengan istilah Kumite untuk bela diri karena jurus Jujutsu seperti kuncian, penyerangan pada titik vital, dan bantingan semuanya termasuk.</p>

	