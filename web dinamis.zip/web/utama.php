<?php 

include "section/header.php";
include "section/menu.php ";


 ?>
	<article>
    <?php
    if(isset($_GET['profile'])){
        include "halaman/profile.php";
    }elseif(isset($_GET['Gerakan'])){
        include "halaman/Gerakan.php";
    }elseif(isset($_GET['contact'])){
        include "halaman/contact.php";
    }else {
        include "halaman/home.php";
    }
    
    ?>
		
	</article>
    
 <?php 
 
 include "section/footer.php"
 
 ?>   
    
 
	