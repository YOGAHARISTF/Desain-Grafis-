
	<menu>
		<a href="utama.php">Home</a>
		<a href="?profile">Profile Karate</a>
		<a href="?Gerakan">Gerakan</a>
		<a href="?contact">logout</a>
	</menu>