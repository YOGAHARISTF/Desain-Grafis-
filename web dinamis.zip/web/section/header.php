<html>
<head>
	<meta charset="UTF-8">
	<title> KARATE </title>
	<link href="style.css" rel="stylesheet" type="text/css">
	<link href="images/karate.img" rel="shortcut icon">
</head>

<body>
	<header>
		<h1>KARATE </h1>
	</header>