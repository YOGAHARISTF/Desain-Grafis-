<footer>
		<p>YOGS &copy; 2018</p>
	</footer>
</body>
</html>